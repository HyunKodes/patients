﻿using Microsoft.AspNetCore.Mvc;

using Microsoft.CodeAnalysis;
using Microsoft.EntityFrameworkCore.Query.SqlExpressions;
using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Web.WebPages.Html;
using TKClassLibrary;

namespace TKPatients.Models
{
    [ModelMetadataTypeAttribute(typeof(TKPatientMetaData))]

    public partial class Patient : IValidatableObject
    {
        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            if (string.IsNullOrEmpty(FirstName))
                yield return new ValidationResult("First name cannot be empty or blank", new[] { "FirstName" });
            else
                FirstName = TKValidation.TKCapitalize(FirstName);
            if (string.IsNullOrEmpty(LastName))
                yield return new ValidationResult("Last name may not be empty or blank", new[] { "LastName" });
            else
                LastName = TKValidation.TKCapitalize(LastName);
            Address = TKValidation.TKCapitalize(Address);
            City = TKValidation.TKCapitalize(City);
            if (!string.IsNullOrEmpty(ProvinceCode))
            {
                var isProvince = TKValidation.TKProvinceCodeValidation(ProvinceCode);
                if (isProvince == "True")
                {
                    PostalCode = TKValidation.TKPostalCodeValidation(PostalCode);
                    var matchPostalCode = Regex.Match(PostalCode, @"^([a-zA-Z]\d[a-zA-Z]( )?\d[a-zA-Z]\d)$");
                    if (!matchPostalCode.Success)
                    {
                        yield return new ValidationResult("Please enter valid postal code in format A3A 3A3", new[] { "ProvinceCode" });
                    }
                }
                else
                {
                    PostalCode = TKValidation.TKZipCodeValidation(PostalCode);
                    var matchZipCode = Regex.Match(PostalCode, @"^\d{5}(-\d{4})?$");
                    if (!matchZipCode.Success)
                    {
                        yield return new ValidationResult("Please enter valid US zip code", new[] { "PostalCode" });
                    }
                }
            }
            else
            {
                yield return new ValidationResult("Please enter valid province/state code", new[] { "PostalCode" });
            }
            if (!string.IsNullOrEmpty(Ohip))
            {
                Ohip = TKValidation.TKOhipValidation(Ohip);
                var matchOhip = Regex.Match(Ohip, @"^\d{4}-\d{3}-\d{3}-[a-zA-Z]{2}$");
                if (!matchOhip.Success)
                {
                    yield return new ValidationResult("Please enter valid OHIP number in format 5555-555-555-AA", new[] { "Ohip" });
                }
            }
            if (!string.IsNullOrEmpty(HomePhone))
            {
                HomePhone = TKValidation.TKHomePhoneValidation(HomePhone);
                var matchHomePhone = Regex.Match(HomePhone, @"^\d{3}-\d{3}-\d{4}$");
                if (!matchHomePhone.Success)
                {
                    yield return new ValidationResult("Please enter valid phone number", new[] { "HomePhone" });
                }
            }
            if (string.IsNullOrEmpty(Gender))
                yield return new ValidationResult("Gender may not be empty or blank. Please choose between “M”, “F” or “X”  ", new[] { "Gender" });
            else
                Gender = TKValidation.TKCapitalize(Gender);
            if (DateOfBirth > DateTime.Now)
            {
                yield return new ValidationResult("Date of birth cannot be in the future", new[] { "DateOfBirth" });
            }
            if (DateOfDeath > DateTime.Now || DateOfDeath < DateOfBirth)
            {
                yield return new ValidationResult("Date of death cannot be in the future or before date of birth", new[] { "DateOfDeath" });
            }
            if (Deceased == true && !DateOfDeath.HasValue)
            {
                yield return new ValidationResult("Please insert date of death", new[] { "DateOfDate" });
            }
        }
    }
    public class TKPatientMetaData
    {
        public int PatientId { get; set; }
        [Display(Name = "First Name")]
        public string FirstName { get; set; }
        [Display(Name = "Last Name")]
        public string LastName { get; set; }
        [Display(Name = "Street Address")]
        public string Address { get; set; }
        [Display(Name = "City")]
        public string City { get; set; }
        [Display(Name = "Province Code")]
        public string ProvinceCode { get; set; }
        [Display(Name = "Postal Code")]
        public string PostalCode { get; set; }
        [Display(Name = "OHIP")]
        public string Ohip { get; set; }
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0: d, MMM, yyyy}")]
        [Display(Name = "Date of Birth")]
        public DateTime? DateOfBirth { get; set; }
        public bool Deceased { get; set; }
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0: d, MMM, yyyy}")]
        [Display(Name = "Date of Death")]
        public DateTime? DateOfDeath { get; set; }
        [Display(Name = "Home Phone")]
        public string HomePhone { get; set; }
        [Display(Name = "Gender")]
        public string Gender { get; set; }
    }
}
