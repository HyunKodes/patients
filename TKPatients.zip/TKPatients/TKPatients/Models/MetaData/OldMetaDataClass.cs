﻿//using Microsoft.AspNetCore.Mvc;

//using Microsoft.CodeAnalysis;
//using Microsoft.EntityFrameworkCore.Query.SqlExpressions;
//using System;
//using System.Collections.Generic;
//using System.ComponentModel.DataAnnotations;
//using System.Linq;
//using System.Text.RegularExpressions;
//using System.Threading.Tasks;
//using System.Web.WebPages.Html;
//using TKClassLibrary;

//namespace TKPatients.Models
//{
//    [ModelMetadataTypeAttribute(typeof(TKPatientMetaData))]


//    public partial class Patient : IValidatableObject
//    {
//        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
//        {
//            if (string.IsNullOrEmpty(FirstName))
//                yield return new ValidationResult("First name cannot be empty or blank", new[] { "FirstName" });
//            else
//                FirstName = TKValidation.TKCapitalize(FirstName);
//            if (string.IsNullOrEmpty(LastName))
//                yield return new ValidationResult("LastName may not be empty or blank", new[] { "LastName" });
//            else
//                LastName = TKValidation.TKCapitalize(LastName);
//            if (string.IsNullOrEmpty(Gender))
//                yield return new ValidationResult("Gender may not be empty or blank. Please choose between “M”, “F” or “X”  ", new[] { "Gender" });
//            else
//                Gender = TKValidation.TKCapitalize(Gender);
//            if (!string.IsNullOrEmpty(ProvinceCode))
//            {
//                var isProvince = TKValidation.TKProvinceCodeValidation(ProvinceCode);
//                if (isProvince == "True")
//                {
//                    PostalCode = TKValidation.TKPostalCodeFormat(PostalCode);
//                }
//                else
//                {
//                    PostalCode = TKValidation.TKZipCodeValidation(PostalCode);
//                }
//            }
//            else
//            {
//                yield return new ValidationResult("Please enter valid Canadian province code", new[] { "ProvinceCode" });
//            }
//            //Postal code validation
//            var PostalCodeDigits = string.Empty;
//            if (string.IsNullOrEmpty(PostalCode))
//            {
//                yield break;
//            }
//            else
//            {
//                PostalCode = PostalCode.Trim();
//                PostalCodeDigits = TKValidation.TKExtractDigits(PostalCode);
//            }
//            var NumberOfDigits = PostalCodeDigits.Length;
//            if (Convert.ToInt32(NumberOfDigits) == 3)
//            {
//                PostalCode = TKValidation.TKPostalCodeValidation(PostalCode);
//                var matchPostalCode = Regex.Match(PostalCode, @"^([a-zA-Z]\d[a-zA-Z]( )?\d[a-zA-Z]\d)$");
//                if (!matchPostalCode.Success)
//                {
//                    yield return new ValidationResult("Please enter valid postal code in format A3A 3A3");
//                }
//            }
//            else
//            {
//                PostalCode = TKValidation.TKZipCodeValidation(PostalCode);
//                var matchZipCode = Regex.Match(PostalCode, @"^\d{5}(-\d{4})?$");
//                if (!matchZipCode.Success)
//                {
//                    yield return new ValidationResult("Please enter valid US zip code", new[] { "PostalCode" });
//                }
//            }
//            if (!string.IsNullOrEmpty(Ohip))
//            {
//                var matchOhip = Regex.Match(PostalCode, @"^\d{5}-\d{4}-[a-zA-Z]{2}$");
//                if (!matchOhip.Success)
//                {
//                    yield return new ValidationResult("Please enter valid OHIP number in format 55555-5555-AA", new[] { "Ohip" });
//                }
//            }
//            if (!string.IsNullOrEmpty(HomePhone))
//            {
//                HomePhone = TKValidation.TKExtractDigits(HomePhone);
//                var matchHomePhone = Regex.Match(HomePhone, @"^\d{3}-\d{3}-\d{4}$");
//                if (!matchHomePhone.Success)
//                {
//                    yield return new ValidationResult("Please enter valid phone number", new[] { "HomePhone" });
//                }
//            }





//            //Address = Address.Trim();
//            //City = City.Trim();
//            //Ohip = Ohip.Trim();
//            //HomePhone = HomePhone.Trim();


//        }
//    }



//    public class TKPatientMetaData
//    {
//        public int PatientId { get; set; }
//        [Display(Name = "First Name")]
//        public string FirstName { get; set; }
//        [Display(Name = "Last Name")]
//        public string LastName { get; set; }
//        [Display(Name = "Street Address")]
//        public string Address { get; set; }
//        [Display(Name = "City")]
//        public string City { get; set; }
//        [Display(Name = "Province Code")]
//        public string ProvinceCode { get; set; }
//        [Display(Name = "Postal Code")]
//        public string PostalCode { get; set; }
//        [Display(Name = "OHIP")]
//        public string Ohip { get; set; }
//        [DisplayFormat(ApplyFormatInEditMode = false, DataFormatString = "{0: d, MMM, yyyy}")]
//        [Display(Name = "Date of Birth")]
//        public DateTime? DateOfBirth { get; set; }
//        public bool Deceased { get; set; }
//        [DisplayFormat(ApplyFormatInEditMode = false, DataFormatString = "{0: d, MMM, yyyy}")]
//        [Display(Name = "Date of Death")]
//        public DateTime? DateOfDeath { get; set; }
//        [Display(Name = "Home Phone")]
//        public string HomePhone { get; set; }
//        //[Required]
//        [Display(Name = "Gender")]
//        public string Gender { get; set; }


//    }
//}
