﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using TKPatients.Models;

namespace TKPatients.Controllers
{
    //[Authorize(Roles = "Admin")]

    public class TKRoleController : Controller
    {

        private readonly RoleManager<IdentityRole> roleManager;
        private readonly UserManager<IdentityUser> userManager;

        public TKRoleController(RoleManager<IdentityRole> roleMaager,
                                        UserManager<IdentityUser> userManager)
        {
            this.roleManager = roleMaager;
            this.userManager = userManager;
        }

        public IActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public IActionResult CreateRole()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> CreateRole(CreateRole model)
        {
            if (ModelState.IsValid)
            {
                IdentityRole role = new IdentityRole { Name = model.RoleName };

                var result = await roleManager.CreateAsync(role);

                if (result.Succeeded)
                {
                    return RedirectToAction("ListRole");
                }

                foreach (var error in result.Errors)
                {
                    ModelState.AddModelError("", error.Description);
                }
            }
            return View(model);
        }

        [HttpPost]
        public async Task<IActionResult> DeleteRole(string id)
        {

            var role = await roleManager.FindByNameAsync(id);
            if (role == null)
            {
                ViewBag.Errormessage = $"Role with Id = {id} cannot be found";
                return View();
            }
            else
            {
                var result = await roleManager.DeleteAsync(role);
                if (result.Succeeded)
                {
                    TempData["message"] = "Successfully deleted";
                    return RedirectToAction("ListRole");

                }
                foreach (var error in result.Errors)
                {
                    ModelState.AddModelError("", error.Description);
                }
            }
            return View("ListRole");


        }

        [HttpGet]
        [AllowAnonymous]

        public IActionResult ListRole()
        {
            var roles = roleManager.Roles;
            return View(roles);
        }
    }
}
