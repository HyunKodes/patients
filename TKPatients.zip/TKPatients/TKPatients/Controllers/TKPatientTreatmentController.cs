﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using TKPatients.Models;

namespace TKPatients.Controllers
{
    public class TKPatientTreatmentController : Controller
    {
        private readonly PatientsContext _context;

        public TKPatientTreatmentController(PatientsContext context)
        {
            _context = context;
        }

        // GET: TKPatientTreatment
        public async Task<IActionResult> Index(string PatientDiagnosisId)
        {
            if (!string.IsNullOrEmpty(PatientDiagnosisId))
            {
                // store in Cookies or sessions
                Response.Cookies.Append("PatientDiagnosisId", PatientDiagnosisId);
                HttpContext.Session.SetString("PatientDiagnosisId", PatientDiagnosisId);
            }
            else if (Request.Query["PatientDiagnosisId"].Any())
            {
                //store in cookides or session
                Response.Cookies.Append("PatientDiagnosisId", Request.Query["PatientDiagnosisId"].ToString());
                HttpContext.Session.SetString("PatientDiagnosisId", Request.Query["PatientDiagnosisId"].ToString());
                PatientDiagnosisId = Request.Query["PatientDiagnosisId"].ToString();
            }
            else if (Request.Cookies["PatientDiagnosisId"] != null)

            {
                PatientDiagnosisId = Request.Cookies["PatientDiagnosisId"].ToString();
            }
            else if (HttpContext.Session.GetString("PatientDiagnosisId") != null)
            {
                PatientDiagnosisId = HttpContext.Session.GetString("PatientDiagnosisId");
            }
            else
            {
                TempData["message"] = "Please select a patient diagnosis";
                return RedirectToAction("Index", "TKPatientDiagnosis");
            }

            //I included both adjacent tables here, which allowed me to utilize them
            var patientDiagnosis = _context.PatientDiagnosis.Include(b => b.Diagnosis).Include(a=>a.Patient)
                .Where(a => a.PatientDiagnosisId == Convert.ToInt32(PatientDiagnosisId)).FirstOrDefault();
                ViewData["patientName"] = patientDiagnosis.Patient.LastName + ", " + patientDiagnosis.Patient.FirstName;
                ViewData["purpose"] = patientDiagnosis.Diagnosis.Name;

            var patientsContext = _context.PatientTreatment.Include(p => p.PatientDiagnosis).Include(p => p.Treatment)
                .Where(p=>p.PatientDiagnosisId == Convert.ToInt32(PatientDiagnosisId))
                .OrderBy(p=>p.DatePrescribed);
            return View(await patientsContext.ToListAsync());
        }

        // GET: TKPatientTreatment/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            var PatientDiagnosisId = string.Empty;
            if (Request.Cookies["PatientDiagnosisId"] != null)

            {
                PatientDiagnosisId = Request.Cookies["PatientDiagnosisId"].ToString();
            }
            else if (HttpContext.Session.GetString("PatientDiagnosisId") != null)
            {
                PatientDiagnosisId = HttpContext.Session.GetString("PatientDiagnosisId");
            }
            var patientDiagnosis = _context.PatientDiagnosis.Include(b => b.Diagnosis).Include(a => a.Patient)
            .Where(a => a.PatientDiagnosisId == Convert.ToInt32(PatientDiagnosisId)).FirstOrDefault();
                ViewData["patientName"] = patientDiagnosis.Patient.LastName + ", " + patientDiagnosis.Patient.FirstName;
                ViewData["purpose"] = patientDiagnosis.Diagnosis.Name;

            if (id == null)
            {
                return NotFound();
            }

            var patientTreatment = await _context.PatientTreatment
                .Include(p => p.PatientDiagnosis)
                .Include(p => p.Treatment)
                .FirstOrDefaultAsync(m => m.PatientTreatmentId == id);
            if (patientTreatment == null)
            {
                return NotFound();
            }

            return View(patientTreatment);        
            
        }




        // GET: TKPatientTreatment/Create
        public IActionResult Create()
        {
            var PatientDiagnosisId = string.Empty;
            if (Request.Cookies["PatientDiagnosisId"] != null)

            {
                PatientDiagnosisId = Request.Cookies["PatientDiagnosisId"].ToString();
            }
            else if (HttpContext.Session.GetString("PatientDiagnosisId") != null)
            {
                PatientDiagnosisId = HttpContext.Session.GetString("PatientDiagnosisId");
            }

            //
            var patientDiagnosis = _context.PatientDiagnosis.Include(b => b.Diagnosis).Include(a => a.Patient)
            .Where(a => a.PatientDiagnosisId == Convert.ToInt32(PatientDiagnosisId)).FirstOrDefault();
            ViewData["patientName"] = patientDiagnosis.Patient.LastName + ", " + patientDiagnosis.Patient.FirstName;
            ViewData["purpose"] = patientDiagnosis.Diagnosis.Name;

            //this was my fix
            var diagnosisId = patientDiagnosis.DiagnosisId;

            var patientTreatment = string.Empty;
            if (patientTreatment == null)
            {
                return NotFound();
            }
            ViewData["PatientDiagnosisId"] = new SelectList(_context.PatientDiagnosis
                .Where(p=>p.PatientDiagnosisId == Convert.ToInt32(PatientDiagnosisId)), "PatientDiagnosisId", "PatientDiagnosisId");
            //ViewData["TreatmentId"] = new SelectList(_context.Treatment.Include(p => p.PatientTreatment).ThenInclude(p => p.PatientDiagnosis)
            //    .Where(a=>a. == Convert.ToInt32(PatientDiagnosisId)), "TreatmentId", "Name");

            ViewData["TreatmentId"] = new SelectList(_context.Treatment.Where(t=>t.DiagnosisId == diagnosisId), "TreatmentId", "Name");


            return View();

        }

        // POST: TKPatientTreatment/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("PatientTreatmentId,TreatmentId,DatePrescribed,Comments,PatientDiagnosisId")] PatientTreatment patientTreatment)
        {
            if (ModelState.IsValid)
            {
                _context.Add(patientTreatment);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["PatientDiagnosisId"] = new SelectList(_context.PatientDiagnosis, "PatientDiagnosisId", "PatientDiagnosisId", patientTreatment.PatientDiagnosisId);
            ViewData["TreatmentId"] = new SelectList(_context.Treatment.Where(t=>t.TreatmentId == t.DiagnosisId), "TreatmentId", "Name", patientTreatment.TreatmentId);
            return View(patientTreatment);
        }

        // GET: TKPatientTreatment/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            var PatientDiagnosisId = string.Empty;
            if (Request.Cookies["PatientDiagnosisId"] != null)

            {
                PatientDiagnosisId = Request.Cookies["PatientDiagnosisId"].ToString();
            }
            else if (HttpContext.Session.GetString("PatientDiagnosisId") != null)
            {
                PatientDiagnosisId = HttpContext.Session.GetString("PatientDiagnosisId");
            }

            var patientDiagnosis = _context.PatientDiagnosis.Include(b => b.Diagnosis).Include(a => a.Patient)
            .Where(a => a.PatientDiagnosisId == Convert.ToInt32(PatientDiagnosisId)).FirstOrDefault();
            ViewData["patientName"] = patientDiagnosis.Patient.LastName + ", " + patientDiagnosis.Patient.FirstName;
            ViewData["purpose"] = patientDiagnosis.Diagnosis.Name;

            if (id == null)
            {
                return NotFound();
            }

            var patientTreatment = await _context.PatientTreatment.FindAsync(id);
            if (patientTreatment == null)
            {
                return NotFound();
            }
            ViewData["PatientDiagnosisId"] = new SelectList(_context.PatientDiagnosis, "PatientDiagnosisId", "PatientDiagnosisId", patientTreatment.PatientDiagnosisId);
            ViewData["TreatmentId"] = new SelectList(_context.Treatment.Include(p => p.PatientTreatment).ThenInclude(p => p.PatientDiagnosis)
                .Where(t=>t.TreatmentId == patientTreatment.TreatmentId && patientTreatment.PatientDiagnosisId == Convert.ToInt32(PatientDiagnosisId)), "TreatmentId", "Name", patientTreatment.TreatmentId);
            return View(patientTreatment);
        }

        // POST: TKPatientTreatment/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("PatientTreatmentId,TreatmentId,DatePrescribed,Comments,PatientDiagnosisId")] PatientTreatment patientTreatment)
        {
            if (id != patientTreatment.PatientTreatmentId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(patientTreatment);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!PatientTreatmentExists(patientTreatment.PatientTreatmentId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["PatientDiagnosisId"] = new SelectList(_context.PatientDiagnosis, "PatientDiagnosisId", "PatientDiagnosisId", patientTreatment.PatientDiagnosisId);
            ViewData["TreatmentId"] = new SelectList(_context.Treatment, "TreatmentId", "Name", patientTreatment.TreatmentId);
            return View(patientTreatment);
        }

        // GET: TKPatientTreatment/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            var PatientDiagnosisId = string.Empty;
            if (Request.Cookies["PatientDiagnosisId"] != null)

            {
                PatientDiagnosisId = Request.Cookies["PatientDiagnosisId"].ToString();
            }
            else if (HttpContext.Session.GetString("PatientDiagnosisId") != null)
            {
                PatientDiagnosisId = HttpContext.Session.GetString("PatientDiagnosisId");
            }

            var patientDiagnosis = _context.PatientDiagnosis.Include(b => b.Diagnosis).Include(a => a.Patient)
            .Where(a => a.PatientDiagnosisId == Convert.ToInt32(PatientDiagnosisId)).FirstOrDefault();
            ViewData["patientName"] = patientDiagnosis.Patient.LastName + ", " + patientDiagnosis.Patient.FirstName;
            ViewData["purpose"] = patientDiagnosis.Diagnosis.Name;

            if (id == null)
            {
                return NotFound();
            }

            var patientTreatment = await _context.PatientTreatment
                .Include(p => p.PatientDiagnosis)
                .Include(p => p.Treatment)
                .FirstOrDefaultAsync(m => m.PatientTreatmentId == id);
            if (patientTreatment == null)
            {
                return NotFound();
            }

            return View(patientTreatment);
        }

        // POST: TKPatientTreatment/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var patientTreatment = await _context.PatientTreatment.FindAsync(id);
            _context.PatientTreatment.Remove(patientTreatment);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool PatientTreatmentExists(int id)
        {
            return _context.PatientTreatment.Any(e => e.PatientTreatmentId == id);
        }
    }
}
