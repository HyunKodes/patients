﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using TKPatients.Models;

namespace TKPatients.Controllers
{
    public class TKMedicationController : Controller
    {
        private readonly PatientsContext _context;

        public TKMedicationController(PatientsContext context)
        {
            _context = context;
        }

        // GET: TKMedication
        public async Task<IActionResult> Index(string MedicationTypeId)
        {
            if (!string.IsNullOrEmpty(MedicationTypeId))
            {
                // store in Cookies or sessions
                Response.Cookies.Append("MedicationTypeId", MedicationTypeId);
                HttpContext.Session.SetString("MedicationTypeId", MedicationTypeId);
            }
            else if (Request.Query["MedicationTypeId"].Any())
            {
                //store in cookides or session
                Response.Cookies.Append("MedicationTypeId", Request.Query["MedicationTypeId"].ToString());
                HttpContext.Session.SetString("MedicationTypeId", Request.Query["MedicationTypeId"].ToString());
                MedicationTypeId = Request.Query["MedicationTypeId"].ToString();
            }
            else if (Request.Cookies["MedicationTypeId"] != null)

            {
                MedicationTypeId = Request.Cookies["MedicationTypeId"].ToString();
            }
            else if (HttpContext.Session.GetString("MedicationTypeId") != null)
            {
                MedicationTypeId = HttpContext.Session.GetString("MedicationTypeId");
            }
            else
            {
                TempData["message"] = "Please select a medication first";
                return RedirectToAction("Index", "TKMedicationType");
            }

            var medicationType = _context.MedicationType.Where(a => a.MedicationTypeId == Convert.ToInt32(MedicationTypeId)).FirstOrDefault();
            ViewData["mTypeName"] = medicationType.Name;

            var patientsContext = _context.Medication.Include(m => m.ConcentrationCodeNavigation).Include(m => m.DispensingCodeNavigation).Include(m => m.MedicationType)
                .Where(m=>m.MedicationTypeId == Convert.ToInt32(MedicationTypeId))
                .OrderBy(m=>m.Name)
                .ThenBy(m=>m.Concentration);
            return View(await patientsContext.ToListAsync());
        }

        // GET: TKMedication/Details/5
        public async Task<IActionResult> Details(string id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var medication = await _context.Medication
                .Include(m => m.ConcentrationCodeNavigation)
                .Include(m => m.DispensingCodeNavigation)
                .Include(m => m.MedicationType)
                .FirstOrDefaultAsync(m => m.Din == id);
            if (medication == null)
            {
                return NotFound();
            }

            return View(medication);
        }

        // GET: TKMedication/Create
        public IActionResult Create()
        {
            string MedicationTypeId = string.Empty;
            if (Request.Cookies["MedicationTypeId"] != null)
            {
                MedicationTypeId = Request.Cookies["MedicationTypeId"].ToString();
            }
            else if (HttpContext.Session.GetString("MedicationTypeId") != null)
            {
                MedicationTypeId = HttpContext.Session.GetString("MedicationTypeId");
            }
            var medicationType = _context.MedicationType.Where(a => a.MedicationTypeId == Convert.ToInt32(MedicationTypeId)).FirstOrDefault();
            ViewData["mTypeName"] = medicationType.Name;

            ViewData["ConcentrationCode"] = new SelectList(_context.ConcentrationUnit.OrderBy(m => m.ConcentrationCode), "ConcentrationCode", "ConcentrationCode");
            ViewData["DispensingCode"] = new SelectList(_context.DispensingUnit.OrderBy(m => m.DispensingCode), "DispensingCode", "DispensingCode");
            ViewData["MedicationTypeId"] = new SelectList(_context.MedicationType, "MedicationTypeId", "Name");
            return View();
        }

        // POST: TKMedication/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Din,Name,Image,MedicationTypeId,DispensingCode,Concentration,ConcentrationCode")] Medication medication)
        {
            string MedicationTypeId = string.Empty;
            if (Request.Cookies["MedicationTypeId"] != null)
            {
                MedicationTypeId = Request.Cookies["MedicationTypeId"].ToString();
            }
            else if (HttpContext.Session.GetString("MedicationTypeId") != null)
            {
                MedicationTypeId = HttpContext.Session.GetString("MedicationTypeId");
            }
            var medicationType = _context.MedicationType.Where(a => a.MedicationTypeId == Convert.ToInt32(MedicationTypeId)).FirstOrDefault();
            ViewData["mTypeName"] = medicationType.Name;

        // I have no fucking idea what I was trying to do here(below)!!!!! 
            //medication.MedicationTypeId = Convert.ToInt32(MedTypeId);

            var isDuplicate = _context.Medication.Where(a => a.Concentration == medication.Concentration && a.Name == medication.Name);
            if (isDuplicate.Any())
            {
                ModelState.AddModelError("", "The stop is already on file for this route.");
            }
            //var medicationType = _context.MedicationType.Where(a => a.MedicationTypeId == Convert.ToInt32(medication)).FirstOrDefault();
            //ViewData["mTypeName"] = medicationType.Name;

            //var isDuplicate = _context.Medication.Where(a => a.MedicationType.ToString() == medication.Concentration.ToString() && a.MedicationType.ToString() == medication.Name && a.MedicationType.ToString() == medication.ConcentrationCode);
            //if (isDuplicate.Any())
            //{
            //    ModelState.AddModelError("", "The medication is already on for this type");
            //}

            if (ModelState.IsValid)
            {
                _context.Add(medication);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["ConcentrationCode"] = new SelectList(_context.ConcentrationUnit, "ConcentrationCode", "ConcentrationCode", medication.ConcentrationCode);
            ViewData["DispensingCode"] = new SelectList(_context.DispensingUnit, "DispensingCode", "DispensingCode", medication.DispensingCode);
            ViewData["MedicationTypeId"] = new SelectList(_context.MedicationType, "MedicationTypeId", "Name", medication.MedicationTypeId);
            return View(medication);
        }

        // GET: TKMedication/Edit/5
        public async Task<IActionResult> Edit(string id)
        {
            string MedicationTypeId = string.Empty;
            if (Request.Cookies["MedicationTypeId"] != null)
            {
                MedicationTypeId = Request.Cookies["MedicationTypeId"].ToString();
            }
            else if (HttpContext.Session.GetString("MedicationTypeId") != null)
            {
                MedicationTypeId = HttpContext.Session.GetString("MedicationTypeId");
            }
            var medicationType = _context.MedicationType.Where(a => a.MedicationTypeId == Convert.ToInt32(MedicationTypeId)).FirstOrDefault();
            ViewData["mTypeName"] = medicationType.Name;

            if (id == null)
            {
                return NotFound();
            }

            var medication = await _context.Medication.FindAsync(id);
            if (medication == null)
            {
                return NotFound();
            }
            ViewData["ConcentrationCode"] = new SelectList(_context.ConcentrationUnit.OrderBy(m => m.ConcentrationCode), "ConcentrationCode", "ConcentrationCode", medication.ConcentrationCode);
            ViewData["DispensingCode"] = new SelectList(_context.DispensingUnit.OrderBy(m => m.DispensingCode), "DispensingCode", "DispensingCode", medication.DispensingCode);
            ViewData["MedicationTypeId"] = new SelectList(_context.MedicationType, "MedicationTypeId", "Name", medication.MedicationTypeId);
            return View(medication);
        }

        // POST: TKMedication/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(string id, [Bind("Din,Name,Image,MedicationTypeId,DispensingCode,Concentration,ConcentrationCode")] Medication medication)
        {
            string MedicationTypeId = string.Empty;
            if (Request.Cookies["MedicationTypeId"] != null)
            {
                MedicationTypeId = Request.Cookies["MedicationTypeId"].ToString();
            }
            else if (HttpContext.Session.GetString("MedicationTypeId") != null)
            {
                MedicationTypeId = HttpContext.Session.GetString("MedicationTypeId");
            }
            var medicationType = _context.MedicationType.Where(a => a.MedicationTypeId == Convert.ToInt32(MedicationTypeId)).FirstOrDefault();
            ViewData["mTypeName"] = medicationType.Name;

            if (id != medication.Din)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(medication);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!MedicationExists(medication.Din))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["ConcentrationCode"] = new SelectList(_context.ConcentrationUnit, "ConcentrationCode", "ConcentrationCode", medication.ConcentrationCode);
            ViewData["DispensingCode"] = new SelectList(_context.DispensingUnit, "DispensingCode", "DispensingCode", medication.DispensingCode);
            ViewData["MedicationTypeId"] = new SelectList(_context.MedicationType, "MedicationTypeId", "Name", medication.MedicationTypeId);
            return View(medication);
        }

        // GET: TKMedication/Delete/5
        public async Task<IActionResult> Delete(string id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var medication = await _context.Medication
                .Include(m => m.ConcentrationCodeNavigation)
                .Include(m => m.DispensingCodeNavigation)
                .Include(m => m.MedicationType)
                .FirstOrDefaultAsync(m => m.Din == id);
            if (medication == null)
            {
                return NotFound();
            }

            return View(medication);
        }

        // POST: TKMedication/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(string id)
        {
            var medication = await _context.Medication.FindAsync(id);
            _context.Medication.Remove(medication);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool MedicationExists(string id)
        {
            return _context.Medication.Any(e => e.Din == id);
        }
    }
}
