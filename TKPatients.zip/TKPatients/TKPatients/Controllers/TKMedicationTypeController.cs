﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using TKPatients.Models;

namespace TKPatients.Controllers
{
    public class TKMedicationTypeController : Controller
    {
        private readonly PatientsContext _context;

        public TKMedicationTypeController(PatientsContext context)
        {
            _context = context;
        }

        // GET: TKMedicationType
        /// <summary>
        /// The index() function returns the view for the main page. It uses the data from the database table and 
        /// waits for the the function ToListAsync()
        /// </summary>
        /// <returns></returns>
        public async Task<IActionResult> Index()
        {
            return View(await _context.MedicationType.OrderByDescending(m=> m.MedicationTypeId).ToListAsync());

        }

        // GET: TKMedicationType/Details/5
        /// This function shows the details of one of the rows of the table.
        /// It uses the id to get the row.
        /// If id is null or country is null, it returns a error message.
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var medicationType = await _context.MedicationType
                .FirstOrDefaultAsync(m => m.MedicationTypeId == id);
            if (medicationType == null)
            {
                return NotFound();
            }

            return View(medicationType);
        }

        // GET: TKMedicationType/Create
        /// <summary>
        /// This function Create() returns View()
        /// </summary>
        /// <returns></returns>
        public IActionResult Create()
        {
            return View();
        }

        // POST: TKMedicationType/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        /// This function creates and saves the medicationType object to the database. It returns that medicationType object

        public async Task<IActionResult> Create([Bind("MedicationTypeId,Name")] MedicationType medicationType)
        {
            if (ModelState.IsValid)
            {
                _context.Add(medicationType);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(medicationType);
        }

        // GET: TKMedicationType/Edit/5
        /// The edit function takes the parameter id and if it is null it returns a error message.
        /// It also returns error message if medicationType is null and it also returns it as a view.
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var medicationType = await _context.MedicationType.FindAsync(id);
            if (medicationType == null)
            {
                return NotFound();
            }
            return View(medicationType);
        }

        // POST: TKMedicationType/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        ///This edit function takes id as the first parameter and if the received id does not equal medicationType.MedicationTypeId,
        ///it returns an error. If it is valid it tries to update the entry and it returns the nameof(Index))
        ///If it is not found, it returns an error, otherwise it throws an exception.
        ///It returns medicationType through view()
        ///
        public async Task<IActionResult> Edit(int id, [Bind("MedicationTypeId,Name")] MedicationType medicationType)
        {
            if (id != medicationType.MedicationTypeId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(medicationType);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!MedicationTypeExists(medicationType.MedicationTypeId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(medicationType);
        }

        // GET: TKMedicationType/Delete/5
        /// <summary>
        /// The delete function uses the id as parameter
        /// if this id is null, it returns an error
        /// There is a await part. Not sure how this works.
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var medicationType = await _context.MedicationType
                .FirstOrDefaultAsync(m => m.MedicationTypeId == id);
            if (medicationType == null)
            {
                return NotFound();
            }

            return View(medicationType);
        }

        // POST: TKMedicationType/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        ///This DeleteConfirmed(id) functions also contain awaits. This calling/response format means it is waiting for
        ///the events to happen before proceding
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var medicationType = await _context.MedicationType.FindAsync(id);
            _context.MedicationType.Remove(medicationType);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        /// <summary>
        /// This function retuns MedicationType.Any() function
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        private bool MedicationTypeExists(int id)
        {
            return _context.MedicationType.Any(e => e.MedicationTypeId == id);
        }
    }
}
