﻿using System;

namespace TKClassLibrary
{
    public class Class1
    {
    }
}
