﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
namespace TKClassLibrary
{
    public static class TKValidation
    {

        public static string TKCapitalize(string input)
        {
            if (string.IsNullOrEmpty(input))
            {
                return string.Empty;
            }
            input = input.ToLower().Trim();
            string[] inputArray = input.Split(" ");
            string result = string.Empty;
            foreach (var s in inputArray)
            {
                result += s.Substring(0, 1).ToUpper() + s.Substring(1) + " ";
            }
            return result;
        }

        public static string TKExtractDigits(string input)
        {
            var result = "";
            for (int i = 0; i < input.Length; i++)
            {
                if (Char.IsDigit(input[i]))
                    result += input[i];
            }
            return result;
        }

        public static string TKProvinceCodeValidation(string input)
        {
            var result = input.Trim().ToUpper();
            if (result == "AB" || result == "BC" || result == "MB" || result == "NB" || result == "NL" || result == "NT" || result == "NS" || result == "NU" || result == "ON" || result == "PE" || result == "QC" || result == "SK" || result == "YT")
            {
                return bool.TrueString;
            }
            return result;
        }

        public static string TKPostalCodeValidation(string input)
        {
            if (string.IsNullOrEmpty(input))
            {
                return bool.TrueString;
            }
            string result = string.Empty;
            if (input.Length == 6)
            {
                result +=
                    input.Substring(0, 1).ToUpper() +
                    input.Substring(1, 1) +
                    input.Substring(2, 1).ToUpper() +
                    " " +
                    input.Substring(3, 1) +
                    input.Substring(4, 1).ToUpper() +
                    input.Substring(5, 1);
                return result;
            }
            if (input.Length == 7)
            {
                result +=
                    input.Substring(0, 1).ToUpper() +
                    input.Substring(1, 1) +
                    input.Substring(2, 1).ToUpper() +
                    input.Substring(4, 1) +
                    input.Substring(5, 1).ToUpper() +
                    input.Substring(6, 1);
                return result;
            }
            return input;
        }

        public static string TKZipCodeValidation(string input)
        {
            input = TKExtractDigits(input);
            var result = string.Empty;
            if (string.IsNullOrEmpty(input))
            {
                return bool.TrueString;
            }
            if (input.Length == 9)
            {
                for (int i = 0; i < 9; i++)
                {
                    result += input[i];
                    if (result.Length == 5)
                    {
                        result += "-";
                    }
                }
                return result;
            }
            if (input.Length == 5)
            {
                for (int i = 0; i < 5; i++)
                {
                    result += input[i];
                }
            }
            return result;
        }
        public static string TKOhipValidation(string input)
        {
            var letters = input.Substring(Math.Max(0, input.Length - 2)).ToUpper();
            input = TKExtractDigits(input);
            string result = string.Empty;
            var matchLetters = Regex.Match(letters, @"^[A-Z]{2}$");
            if (matchLetters.Success)
            {
                result +=
                    input.Substring(0, 4) +
                    "-" +
                    input.Substring(4, 3) +
                    "-" +
                    input.Substring(7, 3) +
                    "-" +
                    letters;
                return result;
            }
            else
            {
                return input;
            }
        }

        public static string TKHomePhoneValidation(string input)
        {
            input = TKExtractDigits(input);
            string result = string.Empty;
            if (input.Length == 10)
            {
                try
                {
                    result +=
                        input.Substring(0, 3) +
                        "-" +
                        input.Substring(3, 3) +
                        "-" +
                        input.Substring(6, 4);
                    return result;

                }
                catch
                {
                    return input;
                }
            }
            return result;
        }
    }
}
